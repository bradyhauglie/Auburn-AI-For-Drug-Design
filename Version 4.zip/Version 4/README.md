---
title: AI (ChatGPT) for Drug Discovery - Auburn University Senior Design Project
colorFrom: gray
colorTo: gray
sdk: gradio
sdk_version: 5.23.1
app_file: app.py
pinned: false
license: apache-2.0
short_description: AI-powered drug discovery platform for molecular design
---

# AI-Powered Drug Discovery Platform

An integrated platform leveraging AI capabilities for computer-aided drug design and discovery. Developed as a Senior Design project at Auburn University's Department of Computer Science and Software Engineering during Spring 2025.

## Features

- **Target Analysis**: Analyze protein targets and evaluate compounds against specific drug targets
- **Protein Structure Analysis**: Identify binding sites and drug interaction opportunities
- **Compound Optimization**: Get AI-assisted structure modifications to improve drug-like properties
- **Property Calculation**: Calculate molecular properties and predict ADME profiles with RDKit
- **Compound Screening**: Screen multiple compounds against customizable drug-likeness criteria

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/ai-drug-discovery.git
cd ai-drug-discovery

# Install dependencies
pip install -r requirements.txt

# Launch the application
python app.py
```

## Usage

The platform provides a web interface with five main tabs:

1. **Setup & Configuration**: Enter your OpenAI API key
2. **Target Analysis**: Analyze predefined targets or evaluate compounds against targets
3. **General Protein Analysis**: Analyze any protein structure by PDB ID
4. **Compound Design & Optimization**: Visualize and optimize molecular structures
5. **Compound Screening**: Screen multiple compounds against customizable criteria

Test examples are provided in the Files tab to demonstrate the platform's capabilities.

## Project Information

### Team Members
- Brady Hauglie
- Cale Johnson
- Spencer Purdy

### Faculty Oversight
Dr. Gerry Dozier, Professor, Department of Computer Science and Software Engineering  

### Project Sponsor
Dr. Rajesh Amin, Department of Drug Discovery and Development, Auburn University

### Academic Term
Spring 2025, COMP-4710 Senior Design

## Technologies

- Python with RDKit for computational chemistry
- OpenAI API for AI-assisted analysis and optimization
- Gradio for the web interface
- BioPython for protein structure analysis

## License

This project is licensed under the Apache License 2.0 - see the LICENSE file for details. The Apache License is chosen to provide patent protection in addition to copyright, which is particularly relevant for drug discovery applications.

## Citation

If you use this software in your research, please cite:
```
Hauglie, B., Johnson, C., & Purdy, S. (2025). AI-Powered Drug Discovery Platform. 
Auburn University Senior Design Project, Department of Computer Science and Software Engineering.
```