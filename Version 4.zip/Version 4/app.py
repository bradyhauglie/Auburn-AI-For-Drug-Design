# Import required libraries
import os
import json
from openai import OpenAI
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem, Draw, Descriptors, rdMolDescriptors, Lipinski, Crippen
from rdkit.Chem.Draw import rdMolDraw2D
from Bio import PDB
import requests
import gradio as gr
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime
import py3Dmol
import matplotlib.pyplot as plt
import io
import base64
import re
import hashlib
import csv
import tempfile

#-------------------------------------------------------------------------------
# Configuration Settings
#-------------------------------------------------------------------------------

class Config:
    """Global configuration settings for the platform"""
    MAX_TOKENS = 2000
    MODEL_NAME = "gpt-4"
    TEMPERATURE = 0.7
    CACHE_SIZE = 1000
    COMPOUNDS_PER_MINUTE = 2000  # Target processing speed
    PDB_BASE_URL = "https://files.rcsb.org/download/"
    
    # Common protein targets with PDB IDs
    PROTEIN_TARGETS = {
        "EGFR": {
            "pdb_id": "1M17", 
            "description": "Epidermal growth factor receptor, a target for cancer therapeutics",
            "ligands": ["AQ4", "IRE"]
        },
        "ACE2": {
            "pdb_id": "1R42", 
            "description": "Angiotensin-converting enzyme 2, important in cardiovascular disease",
            "ligands": ["MLZ"]
        },
        "COX-2": {
            "pdb_id": "5KIR", 
            "description": "Cyclooxygenase-2, a target for anti-inflammatory drugs",
            "ligands": ["5KI"]
        },
        "HIV-1_Protease": {
            "pdb_id": "3EKV",
            "description": "HIV-1 protease, essential for viral replication and a key drug target",
            "ligands": ["ROC"]
        }
    }
    
    # Standard drug-likeness rules (Lipinski's Rule of 5 and extensions)
    DRUGLIKE_RULES = {
        "MW": {"max": 500},
        "LogP": {"min": -0.4, "max": 5.0},
        "TPSA": {"max": 140},
        "HBD": {"max": 5},
        "HBA": {"max": 10},
        "RotBonds": {"max": 10},
        "pKa": {"min": 4.0, "max": 10.0}
    }
    
    # Security settings
    API_KEY_TIMEOUT = 300  # Seconds to keep API key in memory

#-------------------------------------------------------------------------------
# Security Utilities
#-------------------------------------------------------------------------------

class SecurityUtil:
    """Utilities for handling security concerns"""
    
    @staticmethod
    def validate_api_key(api_key: str) -> bool:
        """Validate OpenAI API key format"""
        # Just check that the key isn't empty
        return bool(api_key and isinstance(api_key, str))
        
    @staticmethod
    def sanitize_input(input_str: str) -> str:
        """
        Basic sanitization of user inputs
        
        Args:
            input_str: The string to sanitize
            
        Returns:
            str: Sanitized string
        """
        if not input_str or not isinstance(input_str, str):
            return ""
        # Remove potentially dangerous characters
        return re.sub(r'[;<>&$]', '', input_str)
    
    @staticmethod
    def get_key_hash(api_key: str) -> str:
        """
        Create a hash of the API key for identification without storing the key
        
        Args:
            api_key: The API key to hash
            
        Returns:
            str: Hash representation of the key
        """
        if not api_key:
            return ""
        return hashlib.sha256(api_key.encode()).hexdigest()[:8]

#-------------------------------------------------------------------------------
# Memory Management
#-------------------------------------------------------------------------------

class MemoryManager:
    """Handles caching of results to improve performance"""

    def __init__(self, cache_size: int = Config.CACHE_SIZE):
        """
        Initialize the memory manager
        
        Args:
            cache_size: Maximum number of items to keep in cache
        """
        self.cache = {}
        self.cache_size = cache_size

    def add_to_memory(self, key: str, value: Any) -> None:
        """
        Add item to cache, removing oldest entry if cache is full
        
        Args:
            key: Unique identifier for the cached item
            value: Data to be cached
        """
        if len(self.cache) >= self.cache_size:
            oldest_key = min(self.cache.keys(),
                           key=lambda k: self.cache[k]['timestamp'])
            del self.cache[oldest_key]
        self.cache[key] = {
            'value': value,
            'timestamp': datetime.now()
        }

    def get_from_memory(self, key: str) -> Any:
        """
        Retrieve item from cache if it exists
        
        Args:
            key: Unique identifier for the cached item
            
        Returns:
            Any: Cached value or None if not found
        """
        if key in self.cache:
            return self.cache[key]['value']
        return None

#-------------------------------------------------------------------------------
# Error Handling
#-------------------------------------------------------------------------------

class DrugDesignError(Exception):
    """Base exception class for drug design errors"""
    pass

class StructureError(DrugDesignError):
    """Exception for molecular structure errors"""
    pass

class DockingError(DrugDesignError):
    """Exception for docking process errors"""
    pass

class APIError(DrugDesignError):
    """Exception for API-related errors"""
    pass

#-------------------------------------------------------------------------------
# Protein Structure Management
#-------------------------------------------------------------------------------

class PDBManager:
    """Handles downloading and processing of protein structures from PDB"""

    @staticmethod
    def download_pdb_structure(pdb_id: str) -> str:
        """
        Download PDB structure from RCSB PDB database
        
        Args:
            pdb_id: The PDB identifier for the protein structure
            
        Returns:
            str: Path to the downloaded file
            
        Raises:
            DrugDesignError: If download fails
        """
        # Validate PDB ID format
        if not re.match(r'^[0-9A-Za-z]{4}$', pdb_id):
            raise DrugDesignError("Invalid PDB ID format")
            
        url = f"{Config.PDB_BASE_URL}{pdb_id}.pdb"
        try:
            response = requests.get(url)
            if response.status_code == 200:
                temp_file = f"temp_{pdb_id}.pdb"
                with open(temp_file, 'w') as f:
                    f.write(response.text)
                return temp_file
            else:
                raise DrugDesignError(f"Error downloading PDB: {response.status_code}")
        except Exception as e:
            raise DrugDesignError(f"PDB download error: {str(e)}")
    
    @staticmethod
    def get_binding_site_residues(pdb_file: str, ligand_id: str = None) -> List[str]:
        """
        Identify binding site residues in a protein structure
        
        Args:
            pdb_file: Path to PDB file
            ligand_id: Optional ligand identifier to find binding site
            
        Returns:
            List[str]: List of binding site residue identifiers
        """
        try:
            parser = PDB.PDBParser(QUIET=True)
            structure = parser.get_structure("protein", pdb_file)
            
            binding_residues = []
            
            # If ligand ID is provided, find residues near the ligand
            if ligand_id:
                ligand = None
                for model in structure:
                    for chain in model:
                        for residue in chain:
                            if residue.get_resname() == ligand_id:
                                ligand = residue
                                break
                
                if ligand:
                    # Find all residues within 5 Angstroms of the ligand
                    for model in structure:
                        for chain in model:
                            for residue in chain:
                                if residue.get_resname() != ligand_id:
                                    for atom in residue:
                                        for ligand_atom in ligand:
                                            if atom - ligand_atom < 5.0:  # Distance in Angstroms
                                                binding_residues.append(f"{residue.get_resname()}_{residue.get_id()[1]}")
                                                break
            
            return list(set(binding_residues))  # Remove duplicates
        except Exception as e:
            raise DrugDesignError(f"Error identifying binding sites: {str(e)}")

#-------------------------------------------------------------------------------
# Molecular Visualization
#-------------------------------------------------------------------------------

class MoleculeVisualizer:
    """Handles 2D and 3D visualization of molecular structures"""

    @staticmethod
    def generate_2d_image(smiles: str, highlight_substructures: List[str] = None) -> str:
        """
        Generate 2D molecular structure image from SMILES, with optional highlighting
        
        Args:
            smiles: SMILES string representation of the molecule
            highlight_substructures: Optional list of SMARTS patterns to highlight
            
        Returns:
            str: Base64-encoded image
            
        Raises:
            StructureError: If SMILES is invalid
        """
        try:
            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                raise StructureError("Invalid SMILES string")
                
            # Set up drawing parameters for improved visualization
            d2d = rdMolDraw2D.MolDraw2DCairo(400, 300)
            d2d.SetFontSize(0.8)
            
            # If highlight substructures are provided, highlight them
            if highlight_substructures:
                hit_atoms = []
                hit_bonds = []
                hit_atom_colors = {}
                
                for i, pattern in enumerate(highlight_substructures):
                    pattern_mol = Chem.MolFromSmarts(pattern)
                    if pattern_mol:
                        matches = mol.GetSubstructMatches(pattern_mol)
                        for match in matches:
                            for atom_idx in match:
                                hit_atoms.append(atom_idx)
                                # Assign colors based on the pattern index
                                hit_atom_colors[atom_idx] = (1.0, 0.4 * i % 1.0, 0.2 * i % 1.0)
                
                drawer = rdMolDraw2D.PrepareMolForDrawing(mol)
                d2d.DrawMoleculeWithHighlights(drawer, "", hit_atoms, hit_bonds, hit_atom_colors, {})
            else:
                drawer = rdMolDraw2D.PrepareMolForDrawing(mol)
                d2d.DrawMolecule(drawer)
                
            d2d.FinishDrawing()
            png_data = d2d.GetDrawingText()
            
            return base64.b64encode(png_data).decode()
        except Exception as e:
            raise DrugDesignError(f"2D visualization error: {str(e)}")

    @staticmethod
    def generate_3d_structure(smiles: str) -> str:
        """
        Generate 3D molecular structure visualization
        
        Args:
            smiles: SMILES string representation of the molecule
            
        Returns:
            str: XYZ coordinates block
            
        Raises:
            StructureError: If SMILES is invalid
        """
        try:
            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                raise StructureError("Invalid SMILES string")
            mol = Chem.AddHs(mol)
            AllChem.EmbedMolecule(mol, randomSeed=42)
            AllChem.MMFFOptimizeMolecule(mol)
            return Chem.MolToXYZBlock(mol)
        except Exception as e:
            raise DrugDesignError(f"3D visualization error: {str(e)}")

#-------------------------------------------------------------------------------
# Property Calculation
#-------------------------------------------------------------------------------

class PropertyCalculator:
    """Calculates molecular properties and ADME predictions"""

    @staticmethod
    def calculate_properties(mol) -> Dict[str, float]:
        """
        Calculate basic molecular properties
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            Dict[str, float]: Dictionary of calculated properties
            
        Raises:
            DrugDesignError: If property calculation fails
        """
        try:
            properties = {
                'MW': Descriptors.ExactMolWt(mol),
                'LogP': Descriptors.MolLogP(mol),
                'TPSA': Descriptors.TPSA(mol),
                'HBA': rdMolDescriptors.CalcNumHBA(mol),
                'HBD': rdMolDescriptors.CalcNumHBD(mol),
                'RotBonds': rdMolDescriptors.CalcNumRotatableBonds(mol),
                'QED': Descriptors.qed(mol),
                'MolSA': PropertyCalculator._calculate_molecular_surface_area(mol),
                'AromaticRings': rdMolDescriptors.CalcNumAromaticRings(mol),
                'HeavyAtoms': mol.GetNumHeavyAtoms(),
                'Csp3': PropertyCalculator._calculate_fraction_csp3(mol),
                'ChiralCenters': len(Chem.FindMolChiralCenters(mol, includeUnassigned=True))
            }
            return properties
        except Exception as e:
            raise DrugDesignError(f"Property calculation error: {str(e)}")

    @staticmethod
    def predict_adme(mol) -> Dict[str, float]:
        """
        Predict ADME properties
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            Dict[str, float]: Dictionary of ADME predictions
            
        Raises:
            DrugDesignError: If prediction fails
        """
        try:
            predictions = {
                'Oral_Bioavailability': PropertyCalculator._predict_oral_bioavailability(mol),
                'CYP_Inhibition': PropertyCalculator._predict_cyp_inhibition(mol),
                'hERG_Inhibition': PropertyCalculator._predict_herg_inhibition(mol),
                'SolubilityClass': PropertyCalculator._predict_solubility_class(mol),
                'PGP_Substrate': PropertyCalculator._predict_pgp_substrate(mol),
                'Permeability': PropertyCalculator._predict_permeability(mol),
                'Druglikeness': PropertyCalculator._calculate_druglikeness_score(mol)
            }
            return predictions
        except Exception as e:
            raise DrugDesignError(f"ADME prediction error: {str(e)}")

    @staticmethod
    def _calculate_molecular_surface_area(mol) -> float:
        """Calculate molecular surface area"""
        return rdMolDescriptors.CalcLabuteASA(mol)

    @staticmethod
    def _calculate_fraction_csp3(mol) -> float:
        """Calculate fraction of sp3 hybridized carbons"""
        try:
            carbon_count = 0
            sp3_count = 0
            for atom in mol.GetAtoms():
                if atom.GetSymbol() == 'C':
                    carbon_count += 1
                    if atom.GetHybridization() == Chem.rdchem.HybridizationType.SP3:
                        sp3_count += 1
            if carbon_count == 0:
                return 0
            return sp3_count / carbon_count
        except:
            return 0

    @staticmethod
    def _predict_permeability(mol) -> float:
        """
        Predict membrane permeability using physicochemical parameters
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Predicted permeability score (0.0-1.0)
        """
        # Extract key parameters for permeability prediction
        mw = Descriptors.ExactMolWt(mol)
        logp = Descriptors.MolLogP(mol)
        tpsa = Descriptors.TPSA(mol)
        hbd = rdMolDescriptors.CalcNumHBD(mol)
        hba = rdMolDescriptors.CalcNumHBA(mol)
        rotb = rdMolDescriptors.CalcNumRotatableBonds(mol)
        
        # Score each parameter on a scale of 0.0-1.0 based on permeability data
        mw_score = 1.0 if mw <= 400 else max(0, 1 - (mw - 400) / 200)
        logp_score = 1.0 if 1 <= logp <= 4 else max(0, 1 - min(abs(logp - 1), abs(logp - 4)) / 3)
        tpsa_score = 1.0 if tpsa <= 120 else max(0, 1 - (tpsa - 120) / 80)
        hbd_score = 1.0 if hbd <= 4 else max(0, 1 - (hbd - 4) / 3)
        hba_score = 1.0 if hba <= 8 else max(0, 1 - (hba - 8) / 5)
        rotb_score = 1.0 if rotb <= 8 else max(0, 1 - (rotb - 8) / 4)
        
        # Weight the scores
        weighted_score = (
            0.25 * logp_score + 
            0.20 * tpsa_score + 
            0.20 * mw_score + 
            0.15 * hbd_score + 
            0.10 * hba_score + 
            0.10 * rotb_score
        )
        
        # Return final score between 0.0-1.0
        return min(1.0, max(0.0, weighted_score))

    @staticmethod
    def _predict_oral_bioavailability(mol) -> float:
        """
        Predict oral bioavailability using Lipinski's Rule of 5 and Veber's rules
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Predicted bioavailability score
        """
        # Lipinski's Rule of 5
        mw = Descriptors.ExactMolWt(mol)
        logp = Descriptors.MolLogP(mol)
        hbd = rdMolDescriptors.CalcNumHBD(mol)
        hba = rdMolDescriptors.CalcNumHBA(mol)
        
        # Veber's rules
        rotb = rdMolDescriptors.CalcNumRotatableBonds(mol)
        tpsa = Descriptors.TPSA(mol)
        
        lipinski_violations = 0
        if mw > 500: lipinski_violations += 1
        if logp > 5: lipinski_violations += 1
        if hbd > 5: lipinski_violations += 1
        if hba > 10: lipinski_violations += 1
        
        veber_violations = 0
        if rotb > 10: veber_violations += 1
        if tpsa > 140: veber_violations += 1
        
        # Combined score
        lipinski_score = 1.0 - (lipinski_violations * 0.25)
        veber_score = 1.0 - (veber_violations * 0.5)
        
        return max(0, min(1.0, (lipinski_score * 0.7) + (veber_score * 0.3)))

    @staticmethod
    def _calculate_druglikeness_score(mol) -> float:
        """
        Calculate overall druglikeness score
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Druglikeness score (0-1)
        """
        mw = Descriptors.ExactMolWt(mol)
        logp = Descriptors.MolLogP(mol)
        tpsa = Descriptors.TPSA(mol)
        hbd = rdMolDescriptors.CalcNumHBD(mol)
        hba = rdMolDescriptors.CalcNumHBA(mol)
        rotb = rdMolDescriptors.CalcNumRotatableBonds(mol)
        
        # Score each parameter (0-1)
        mw_score = 1.0 if mw <= 500 else max(0, 1 - (mw - 500) / 250)
        logp_score = 1.0 if 0 <= logp <= 5 else max(0, 1 - min(abs(logp - 0), abs(logp - 5)) / 2)
        tpsa_score = 1.0 if 20 <= tpsa <= 130 else max(0, 1 - min(abs(tpsa - 20), abs(tpsa - 130)) / 50)
        hbd_score = 1.0 if hbd <= 5 else max(0, 1 - (hbd - 5) / 3)
        hba_score = 1.0 if hba <= 10 else max(0, 1 - (hba - 10) / 5)
        rotb_score = 1.0 if rotb <= 10 else max(0, 1 - (rotb - 10) / 5)
        
        # Include QED score if possible
        try:
            qed = Descriptors.qed(mol)
        except:
            qed = 0.5  # Default value if calculation fails
        
        # Weighted average
        return 0.6 * qed + 0.4 * ((mw_score + logp_score + tpsa_score + hbd_score + hba_score + rotb_score) / 6)

    @staticmethod
    def _predict_cyp_inhibition(mol) -> float:
        """
        Predict CYP inhibition potential using structural features
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Predicted inhibition score
        """
        # Check for common structural alerts for CYP inhibition
        alerts = [
            '[#6]-[#6](=[#8])-[#6]',  # Beta-ketone
            '[#6]-[#7]-c:c:c:c',      # Aniline
            'c1:c:c:c:c:c:1-[#8]',    # Phenol
            'c1:c:c:c(:c:c:1)-[#7]',  # Aniline derivative
            '[#6]-[#16]-[#6]'         # Thioether
        ]
        
        has_alert = False
        for alert in alerts:
            pattern = Chem.MolFromSmarts(alert)
            if pattern and mol.HasSubstructMatch(pattern):
                has_alert = True
                break
        
        # Basic calculation using other factors
        logp = Descriptors.MolLogP(mol)
        base_score = 0.3  # Default score
        
        if has_alert:
            base_score += 0.4
        
        if logp > 3:
            base_score += min(0.3, (logp - 3) * 0.1)
            
        return min(1.0, base_score)

    @staticmethod
    def _predict_herg_inhibition(mol) -> float:
        """
        Predict hERG channel inhibition risk
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Probability of hERG inhibition
        """
        # Simplified model based on known hERG inhibitor features
        logp = Descriptors.MolLogP(mol)
        mw = Descriptors.ExactMolWt(mol)
        basic_nitrogen = mol.HasSubstructMatch(Chem.MolFromSmarts('[#7;!$([#7]~[#8]);!$([#7]~[#7])]'))
        aromatic = mol.HasSubstructMatch(Chem.MolFromSmarts('c1ccccc1'))
        
        # Assign base risk
        risk = 0.1  # Default base risk
        
        # Adjust based on features
        if basic_nitrogen:  # Basic amines are common in hERG inhibitors
            risk += 0.3
        
        if aromatic:  # Aromatic rings can interact with hERG channel
            risk += 0.1
        
        if logp > 3.7:  # Lipophilic compounds have higher hERG risk
            risk += min(0.4, (logp - 3.7) * 0.1)
            
        if mw > 250:  # Larger molecules often have higher hERG affinity
            risk += min(0.1, (mw - 250) * 0.001)
            
        return min(1.0, risk)

    @staticmethod
    def _predict_solubility_class(mol) -> int:
        """
        Predict aqueous solubility class (1-5)
        1 = Very soluble, 5 = Practically insoluble
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            int: Solubility class
        """
        logp = Descriptors.MolLogP(mol)
        tpsa = Descriptors.TPSA(mol)
        hba = rdMolDescriptors.CalcNumHBA(mol)
        hbd = rdMolDescriptors.CalcNumHBD(mol)
        
        # Simplified GSE model (General Solubility Equation)
        if logp <= 1 and (hba + hbd) >= 3:
            return 1  # Very soluble
        elif logp <= 3 and tpsa >= 60:
            return 2  # Soluble
        elif logp <= 5 and tpsa >= 40:
            return 3  # Moderately soluble
        elif logp <= 7:
            return 4  # Slightly soluble
        else:
            return 5  # Practically insoluble

    @staticmethod
    def _predict_pgp_substrate(mol) -> float:
        """
        Predict if compound is P-glycoprotein substrate
        P-gp can pump compounds out of cells, affecting absorption and distribution
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Probability of being a P-gp substrate
        """
        # Known P-gp substrate features
        mw = Descriptors.ExactMolWt(mol)
        hba = rdMolDescriptors.CalcNumHBA(mol)
        rotb = rdMolDescriptors.CalcNumRotatableBonds(mol)
        
        # Base probability
        prob = 0.2
        
        # Adjust based on known P-gp substrate features
        if mw > 400:
            prob += min(0.4, (mw - 400) * 0.002)
            
        if hba > 7:
            prob += min(0.3, (hba - 7) * 0.1)
            
        if rotb > 5:
            prob += min(0.3, (rotb - 5) * 0.05)
            
        return min(1.0, prob)

    @staticmethod
    def _estimate_pka(mol) -> float:
        """
        Estimate pKa of the most basic center
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Estimated pKa
        """
        # Very simplified pKa estimation
        # Look for basic nitrogen patterns
        basic_n_patterns = [
            ('[NH2]', 9.5),     # Primary amine
            ('[NH]', 8.5),      # Secondary amine
            ('[N]', 7.5),       # Tertiary amine
            ('n1cccc1', 5.2),   # Pyridine
            ('n1ccccc1', 5.2),  # Pyridine
            ('n1ccncc1', 4.8)   # Pyrimidine
        ]
        
        # Check for matches
        for pattern, pka in basic_n_patterns:
            if mol.HasSubstructMatch(Chem.MolFromSmarts(pattern)):
                return pka
                
        # Default value if no basic centers found
        return 7.0

    @staticmethod
    def _estimate_logd(mol, ph: float = 7.4) -> float:
        """
        Estimate LogD at given pH
        
        Args:
            mol: RDKit molecule object
            ph: pH value
            
        Returns:
            float: Estimated LogD
        """
        # Simplified LogD estimation
        logp = Descriptors.MolLogP(mol)
        
        # Estimate pKa for the most acidic and basic groups
        acid_pka = PropertyCalculator._estimate_acid_pka(mol)
        base_pka = PropertyCalculator._estimate_pka(mol)
        
        # Adjust LogP based on ionization at given pH
        acid_factor = 1.0 / (1.0 + 10**(ph - acid_pka))
        base_factor = 1.0 / (1.0 + 10**(base_pka - ph))
        
        # If the molecule has both acidic and basic groups
        if acid_pka < 14 and base_pka > 0:
            return logp - 0.5  # Zwitterions tend to have lower LogD
        # If only acidic group is relevant
        elif acid_pka < 14:
            return logp * acid_factor
        # If only basic group is relevant
        elif base_pka > 0:
            return logp * base_factor
        # No ionizable groups
        else:
            return logp

    @staticmethod
    def _estimate_acid_pka(mol) -> float:
        """
        Estimate pKa of the most acidic center
        
        Args:
            mol: RDKit molecule object
            
        Returns:
            float: Estimated acidic pKa
        """
        # Simplified acid pKa estimation
        acid_patterns = [
            ('[OH]c1ccccc1', 10.0),  # Phenol
            ('[OH]C=O', 4.5),        # Carboxylic acid
            ('[SH]', 8.5),           # Thiol
            ('[nH]', 14.0)           # NH in heterocycle
        ]
        
        # Check for matches
        for pattern, pka in acid_patterns:
            if mol.HasSubstructMatch(Chem.MolFromSmarts(pattern)):
                return pka
                
        # Default value if no acidic centers found
        return 15.0  # High value to indicate no acidic group

#-------------------------------------------------------------------------------
# Target Analysis
#-------------------------------------------------------------------------------

class TargetAnalyzer:
    """Analysis for protein targets"""
    
    def __init__(self, memory_manager: MemoryManager):
        """
        Initialize analyzer
        
        Args:
            memory_manager: Memory manager for caching results
        """
        self.memory_manager = memory_manager
        
    def analyze_target(self, api_key: str, target_name: str) -> Dict[str, Any]:
        """
        Analyze a protein target
        
        Args:
            api_key: OpenAI API key
            target_name: Name of the target (from Config.PROTEIN_TARGETS)
            
        Returns:
            Dict[str, Any]: Analysis results
            
        Raises:
            DrugDesignError: If target not found or analysis fails
        """
        if target_name not in Config.PROTEIN_TARGETS:
            raise DrugDesignError(f"Unknown target: {target_name}")
            
        # Check cache first
        cache_key = f"target_analysis_{target_name}"
        cached_result = self.memory_manager.get_from_memory(cache_key)
        if cached_result:
            return cached_result
            
        # Get target information
        target_info = Config.PROTEIN_TARGETS[target_name]
        pdb_id = target_info["pdb_id"]
        description = target_info["description"]
            
        try:
            # Download PDB structure
            pdb_file = PDBManager.download_pdb_structure(pdb_id)
            
            # Identify binding sites if ligands are available
            binding_sites = []
            if "ligands" in target_info and target_info["ligands"]:
                for ligand in target_info["ligands"]:
                    binding_sites.extend(PDBManager.get_binding_site_residues(pdb_file, ligand))
            
            # Create GPT analysis prompt based on target and binding information
            client = OpenAI(api_key=api_key)
            
            prompt = f"""Analyze this protein target for drug discovery:
            Target: {target_name}
            PDB ID: {pdb_id}
            Description: {description}
            
            Known binding site residues: {', '.join(binding_sites) if binding_sites else 'Not identified'}
            
            Provide a detailed analysis including:
            1. Role in disease pathology
            2. Key residues for drug interactions
            3. Preferred ligand characteristics for this target
            4. Unique challenges for this target
            5. Current therapeutic approaches
            6. Most promising chemical scaffolds for this target
            7. Special considerations for drug development"""
            
            response = client.chat.completions.create(
                model=Config.MODEL_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert in structure-based drug design."},
                    {"role": "user", "content": prompt}
                ],
                temperature=Config.TEMPERATURE,
                max_tokens=Config.MAX_TOKENS
            )
            
            # Save and return results
            analysis = {
                'target_name': target_name,
                'pdb_id': pdb_id,
                'binding_sites': binding_sites,
                'analysis': response.choices[0].message.content,
                'timestamp': datetime.now().isoformat()
            }
            
            self.memory_manager.add_to_memory(cache_key, analysis)
            return analysis
            
        except Exception as e:
            raise DrugDesignError(f"Target analysis error: {str(e)}")
            
    def evaluate_compound_for_target(self, api_key: str, target_name: str, smiles: str) -> Dict[str, Any]:
        """
        Evaluate a compound's suitability for a specific target
        
        Args:
            api_key: OpenAI API key
            target_name: Name of the target
            smiles: SMILES string of the compound
            
        Returns:
            Dict[str, Any]: Evaluation results
            
        Raises:
            DrugDesignError: If evaluation fails
        """
        if target_name not in Config.PROTEIN_TARGETS:
            raise DrugDesignError(f"Unknown target: {target_name}")
            
        try:
            # Get molecule
            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                raise StructureError("Invalid SMILES string")
                
            # Calculate properties
            properties = PropertyCalculator.calculate_properties(mol)
            adme = PropertyCalculator.predict_adme(mol)
            
            # Get target analysis
            target_analysis = self.analyze_target(api_key, target_name)
            
            # Create GPT evaluation prompt
            client = OpenAI(api_key=api_key)
            
            prompt = f"""Evaluate this compound for the target {target_name}:
            Target: {target_name}
            SMILES: {smiles}
            
            Molecular properties:
            - MW: {properties['MW']:.2f}
            - LogP: {properties['LogP']:.2f}
            - TPSA: {properties['TPSA']:.2f}
            - HBA: {properties['HBA']}
            - HBD: {properties['HBD']}
            - Druglikeness Score: {adme['Druglikeness']:.2f}
            
            Evaluate:
            1. Likelihood of target binding
            2. Potential activity against the target
            3. Pharmacokinetic considerations
            4. Structural improvements for better target activity
            5. Potential off-target concerns
            6. Overall suitability for further development"""
            
            response = client.chat.completions.create(
                model=Config.MODEL_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert medicinal chemist specializing in drug discovery."},
                    {"role": "user", "content": prompt}
                ],
                temperature=Config.TEMPERATURE,
                max_tokens=Config.MAX_TOKENS
            )
            
            # Return evaluation
            evaluation = {
                'target_name': target_name,
                'smiles': smiles,
                'properties': properties,
                'adme': adme,
                'evaluation': response.choices[0].message.content,
                'timestamp': datetime.now().isoformat()
            }
            
            return evaluation
            
        except Exception as e:
            raise DrugDesignError(f"Compound evaluation error: {str(e)}")

#-------------------------------------------------------------------------------
# Core Drug Design Agent
#-------------------------------------------------------------------------------

class DrugDesignAgent:
    """Main agent for drug design tasks and integration with external services"""

    def __init__(self, memory_manager: MemoryManager):
        """
        Initialize the agent
        
        Args:
            memory_manager: Memory manager for caching results
        """
        self.client = None
        self.memory_manager = memory_manager
        self.visualizer = MoleculeVisualizer()
        self.property_calculator = PropertyCalculator()
        self.target_analyzer = TargetAnalyzer(memory_manager)
        self._last_api_key_hash = None

    def set_api_client(self, api_key: str) -> bool:
        """
        Set up the OpenAI client with an API key
        
        Args:
            api_key: OpenAI API key
            
        Returns:
            bool: Whether the API key is valid
            
        Raises:
            APIError: If API key is invalid
        """
        if not SecurityUtil.validate_api_key(api_key):
            raise APIError("Invalid API key format")
        
        # Create a hash for identification
        key_hash = SecurityUtil.get_key_hash(api_key)
        
        # Only create a new client if the key has changed
        if key_hash != self._last_api_key_hash:
            self.client = OpenAI(api_key=api_key)
            self._last_api_key_hash = key_hash
        
        return True

    def analyze_protein_target(self, api_key: str, pdb_id: str, target_description: str) -> Dict[str, Any]:
        """
        Analyze protein structure and identify potential binding sites
        
        Args:
            api_key: OpenAI API key
            pdb_id: PDB identifier for the protein
            target_description: Description of the target
            
        Returns:
            Dict[str, Any]: Analysis results
            
        Raises:
            DrugDesignError: If analysis fails
        """
        # Set up API client with provided key
        self.set_api_client(api_key)
        
        # Sanitize inputs
        pdb_id = SecurityUtil.sanitize_input(pdb_id)
        target_description = SecurityUtil.sanitize_input(target_description)
        
        # Check cache first
        cache_key = f"protein_analysis_{pdb_id}"
        cached_result = self.memory_manager.get_from_memory(cache_key)
        if cached_result:
            return cached_result

        try:
            # Download PDB structure
            pdb_file = PDBManager.download_pdb_structure(pdb_id)

            # Check if client is None and reinitialize if necessary
            if self.client is None:
                self.client = OpenAI(api_key=api_key)
                self._last_api_key_hash = SecurityUtil.get_key_hash(api_key)

            prompt = f"""Analyze this protein target for drug discovery:
            PDB ID: {pdb_id}
            Description: {target_description}
            Provide a detailed analysis including:
            1. Main binding pockets
            2. Key residues for drug interactions
            3. Type of interactions possible
            4. Special considerations for drug design
            5. Recommended chemical features for ligands
            6. Insights relevant to drug development for this target"""

            response = self.client.chat.completions.create(
                model=Config.MODEL_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert in structure-based drug design."},
                    {"role": "user", "content": prompt}
                ],
                temperature=Config.TEMPERATURE,
                max_tokens=Config.MAX_TOKENS
            )

            analysis = {
                'pdb_id': pdb_id,
                'analysis': response.choices[0].message.content,
                'timestamp': datetime.now().isoformat()
            }

            self.memory_manager.add_to_memory(cache_key, analysis)
            
            # Clean up API client reference only after successful completion
            self.client = None
            
            return analysis

        except Exception as e:
            # Don't clean up client on error, so error handling can use it if needed
            raise DrugDesignError(f"Protein analysis error: {str(e)}")

    def screen_compounds(self, api_key: str, compounds: List[str],
                        screening_criteria: Dict[str, Any], target_focus: str = None) -> Dict[str, Any]:
        """
        Screen compounds against property criteria
        
        Args:
            api_key: OpenAI API key
            compounds: List of SMILES strings
            screening_criteria: Dictionary of property criteria
            target_focus: Optional target focus
            
        Returns:
            Dict[str, Any]: Screening results
            
        Raises:
            DrugDesignError: If screening fails
        """
        try:
            # Use druglikeness criteria if no specific criteria provided
            if not screening_criteria:
                screening_criteria = Config.DRUGLIKE_RULES
            
            batch_size = Config.COMPOUNDS_PER_MINUTE
            results = []

            for i in range(0, len(compounds), batch_size):
                batch = compounds[i:i + batch_size]

                # Process each compound in batch
                for smiles in batch:
                    mol = Chem.MolFromSmiles(smiles)
                    if mol is None:
                        continue

                    # Calculate properties
                    properties = self.property_calculator.calculate_properties(mol)
                    
                    # Calculate ADME properties
                    adme = self.property_calculator.predict_adme(mol)
                    
                    # Check if compound meets screening criteria
                    if self._meets_criteria(properties, screening_criteria):
                        compound_result = {
                            'SMILES': smiles,
                            'properties': properties,
                            'adme': adme
                        }
                        results.append(compound_result)

            # Sort results by druglikeness score
            results.sort(key=lambda x: x['adme']['Druglikeness'] if 'Druglikeness' in x['adme'] else 0, reverse=True)
            
            result_data = {
                'screened_compounds': len(compounds),
                'hits': results,
                'criteria': screening_criteria,
                'target_focus': target_focus,
                'timestamp': datetime.now().isoformat()
            }
            
            # Clean up client if it exists
            if self.client:
                self.client = None
                
            return result_data

        except Exception as e:
            raise DrugDesignError(f"Compound screening error: {str(e)}")
            
    def optimize_compound(self, api_key: str, smiles: str, optimization_goals: List[str], target_name: str = None) -> Dict[str, Any]:
        """
        Optimize compound structure based on specified goals
        
        Args:
            api_key: OpenAI API key
            smiles: SMILES string of the compound
            optimization_goals: List of optimization goals
            target_name: Optional target name for specialized optimization
            
        Returns:
            Dict[str, Any]: Optimization results
            
        Raises:
            DrugDesignError: If optimization fails
        """
        # Set up API client with provided key
        self.set_api_client(api_key)
        
        # Sanitize inputs
        smiles = SecurityUtil.sanitize_input(smiles)
        optimization_goals = [SecurityUtil.sanitize_input(goal) for goal in optimization_goals]
        
        try:
            # Get molecule
            mol = Chem.MolFromSmiles(smiles)
            if not mol:
                raise StructureError("Invalid SMILES string")
                
            # Calculate initial properties
            initial_properties = self.property_calculator.calculate_properties(mol)
            initial_adme = self.property_calculator.predict_adme(mol)
            
            # Create specialized prompt based on optimization focus
            prompt_base = f"""Optimize this chemical structure (SMILES: {smiles}) for the following goals:
            {', '.join(optimization_goals)}
            
            Current properties:
            - MW: {initial_properties['MW']:.2f}
            - LogP: {initial_properties['LogP']:.2f}
            - TPSA: {initial_properties['TPSA']:.2f}
            - HBA: {initial_properties['HBA']}
            - HBD: {initial_properties['HBD']}
            - Druglikeness Score: {initial_adme['Druglikeness']:.2f}
            
            Provide:
            1. 3-5 suggested structural modifications, each with:
               - Chemical rationale
               - Expected property changes
               - Modified SMILES structure
            2. An explanation of how each modification addresses the optimization goals
            3. Prioritize modifications that maintain drug-likeness
            """
            
            # Add target-specific information if provided
            if target_name:
                if target_name in Config.PROTEIN_TARGETS:
                    target_info = Config.PROTEIN_TARGETS[target_name]
                    prompt_base += f"""
                    4. Specifically address how these modifications will improve binding to {target_name} ({target_info['description']})
                    5. Consider appropriate pharmacokinetic properties in your optimization
                    """
            
            # Check if client is None and reinitialize if necessary
            if self.client is None:
                self.client = OpenAI(api_key=api_key)
                self._last_api_key_hash = SecurityUtil.get_key_hash(api_key)
            
            response = self.client.chat.completions.create(
                model=Config.MODEL_NAME,
                messages=[
                    {"role": "system", "content": "You are an expert medicinal chemist specializing in structure-based drug design."},
                    {"role": "user", "content": prompt_base}
                ],
                temperature=Config.TEMPERATURE,
                max_tokens=Config.MAX_TOKENS
            )
    
            # Process the suggestions to structure them
            optimization_text = response.choices[0].message.content
            
            # Extract modified SMILES from the response
            modified_smiles = []
            smiles_pattern = r'SMILES[:=]\s*([^\s,;]+)'
            matches = re.findall(smiles_pattern, optimization_text)
            
            valid_modifications = []
            for mod_smiles in matches:
                # Verify it's a valid structure
                try:
                    mod_mol = Chem.MolFromSmiles(mod_smiles)
                    if mod_mol:
                        mod_properties = self.property_calculator.calculate_properties(mod_mol)
                        mod_adme = self.property_calculator.predict_adme(mod_mol)
                        
                        valid_modifications.append({
                            'smiles': mod_smiles,
                            'properties': mod_properties,
                            'adme': mod_adme
                        })
                except:
                    pass  # Skip invalid structures
            
            result = {
                'original_smiles': smiles,
                'original_properties': initial_properties,
                'original_adme': initial_adme,
                'optimization_goals': optimization_goals,
                'suggestions': optimization_text,
                'valid_modifications': valid_modifications,
                'target_name': target_name,
                'timestamp': datetime.now().isoformat()
            }
            
            # Clean up API client reference only after successful completion
            self.client = None
            
            return result
    
        except Exception as e:
            # Don't clean up client on error
            raise DrugDesignError(f"Compound optimization error: {str(e)}")
            
    def analyze_target(self, api_key: str, target_name: str) -> Dict[str, Any]:
        """
        Analyze a protein target
        
        Args:
            api_key: OpenAI API key
            target_name: Target name
            
        Returns:
            Dict[str, Any]: Analysis results
            
        Raises:
            DrugDesignError: If analysis fails
        """
        return self.target_analyzer.analyze_target(api_key, target_name)
        
    def evaluate_for_target(self, api_key: str, target_name: str, smiles: str) -> Dict[str, Any]:
        """
        Evaluate compound for a specific target
        
        Args:
            api_key: OpenAI API key
            target_name: Target name
            smiles: SMILES string
            
        Returns:
            Dict[str, Any]: Evaluation results
            
        Raises:
            DrugDesignError: If evaluation fails
        """
        return self.target_analyzer.evaluate_compound_for_target(api_key, target_name, smiles)
        
    def process_smiles_input(self, smiles_text: str) -> List[str]:
        """
        Process SMILES strings from input text
        
        Args:
            smiles_text: Text containing SMILES strings, one per line
            
        Returns:
            List[str]: List of valid SMILES strings
            
        Raises:
            DrugDesignError: If no valid compounds found
        """
        try:
            # Split text into lines
            lines = [line.strip() for line in smiles_text.strip().split('\n')]
            
            # Filter empty lines
            compounds = [line for line in lines if line]
            
            # Validate SMILES strings
            valid_compounds = []
            for smiles in compounds:
                mol = Chem.MolFromSmiles(smiles)
                if mol is not None:
                    valid_compounds.append(smiles)
            
            if not valid_compounds:
                raise DrugDesignError("No valid SMILES strings found in the input text")
                
            return valid_compounds
            
        except Exception as e:
            if isinstance(e, DrugDesignError):
                raise e
            raise DrugDesignError(f"Error processing SMILES input: {str(e)}")

    def _meets_criteria(self, properties: Dict[str, float], criteria: Dict[str, Any]) -> bool:
        """
        Check if compound properties meet screening criteria
        
        Args:
            properties: Dictionary of molecular properties
            criteria: Dictionary of screening criteria
            
        Returns:
            bool: Whether the properties meet all criteria
        """
        for prop, value in criteria.items():
            if prop not in properties:
                continue
            if 'min' in value and properties[prop] < value['min']:
                return False
            if 'max' in value and properties[prop] > value['max']:
                return False
        return True
        
#-------------------------------------------------------------------------------
# Enhanced Drug Design Interface
#-------------------------------------------------------------------------------

class DrugDesignInterface:
    """Web interface for drug design platform using Gradio"""

    def __init__(self, drug_design_agent: DrugDesignAgent):
        """
        Initialize the interface
        
        Args:
            drug_design_agent: Drug design agent instance
        """
        self.agent = drug_design_agent
        self.api_key_warning = """⚠️ IMPORTANT: Your API key is stored in memory only for the duration of your session
and is never saved to disk. For maximum security, we recommend using environment variables
for API keys in production environments."""

    def create_interface(self):
        """
        Create the Gradio interface
        
        Returns:
            gr.Blocks: Gradio interface
        """
        with gr.Blocks(title="AI (ChatGPT) for Drug Discovery - Auburn University Senior Design Project") as interface:
            gr.Markdown("""
            # AI (ChatGPT) for Drug Discovery - Auburn University Senior Design Project
            ### Test Examples and Demo Video are Located in the Files Tab in the Top Right Corner
            """)

            # Setup Tab
            with gr.Tab("Setup & Configuration"):
                api_key_input = gr.Textbox(
                    label="OpenAI API Key",
                    placeholder="Enter your OpenAI API key...",
                    type="password"
                )
                gr.Markdown(self.api_key_warning)

            # Target Analysis Tab
            with gr.Tab("Target Analysis"):
                with gr.Row():
                    with gr.Column():
                        target_input = gr.Textbox(
                            label="Enter Target Name",
                            placeholder="EGFR, ACE2, COX-2, or HIV-1_Protease"
                        )
                        analyze_target_button = gr.Button("Analyze Target")
                    with gr.Column():
                        target_analysis = gr.Textbox(
                            label="Target Analysis",
                            lines=12
                        )
                        
                with gr.Row():
                    with gr.Column():
                        compound_for_target_input = gr.Textbox(
                            label="Evaluate SMILES for Target",
                            placeholder="Enter SMILES to evaluate for this target..."
                        )
                        target_name_input = gr.Textbox(
                            label="Target Name",
                            placeholder="Enter target name (EGFR, ACE2, etc.)"
                        )
                        evaluate_target_button = gr.Button("Evaluate for Target")
                    with gr.Column():
                        target_evaluation_output = gr.Textbox(
                            label="Evaluation Results",
                            lines=8
                        )

            # Protein Analysis Tab
            with gr.Tab("General Protein Analysis"):
                with gr.Row():
                    with gr.Column():
                        pdb_id_input = gr.Textbox(
                            label="PDB ID",
                            placeholder="Enter PDB ID (e.g., 1AZ5)"
                        )
                        target_description_input = gr.Textbox(
                            label="Target Description",
                            placeholder="Describe the target and goals...",
                            lines=3
                        )
                        analyze_button = gr.Button("Analyze Protein Target")
                    with gr.Column():
                        protein_analysis_output = gr.Textbox(
                            label="Analysis Results",
                            lines=10
                        )

            # Compound Design Tab
            with gr.Tab("Compound Design & Optimization"):
                with gr.Row():
                    with gr.Column(scale=1):
                        smiles_input = gr.Textbox(
                            label="Compound SMILES",
                            placeholder="Enter SMILES string (e.g., CC(=O)OC1=CC=CC=C1C(=O)O for Aspirin)"
                        )
                        optimization_goals_input = gr.Textbox(
                            label="Optimization Goals",
                            placeholder="Enter goals separated by commas...",
                            lines=2
                        )
                        optimization_target_input = gr.Textbox(
                            label="Optimize for Target (optional)",
                            placeholder="EGFR, ACE2, COX-2, or HIV-1_Protease"
                        )
                        optimize_button = gr.Button("Optimize Compound")
                    with gr.Column(scale=2):
                        mol_2d = gr.Image(label="2D Structure")
                        with gr.Row():
                            mol_properties = gr.JSON(label="Molecular Properties")
                            mol_adme = gr.JSON(label="ADME Predictions")
                        optimization_output = gr.Textbox(label="Optimization Results", lines=8)
                        
            # Compound Screening Tab
            with gr.Tab("Compound Screening"):
                with gr.Row():
                    with gr.Column():
                        compounds_text_input = gr.Textbox(
                            label="Enter SMILES Strings (one per line)",
                            placeholder="Enter SMILES structures, one per line",
                            lines=10,
                            value="""CC(=O)OC1=CC=CC=C1C(=O)O
CC(C)CC1=CC=C(C=C1)C(C)C(=O)O
COC1=C(C=CC(=C1)CC=C)O
COC1=CC=C(C=C1)CCNC
CCN(CC)C(=O)C1=CC=C(C=C1)N"""
                        )
                        screening_criteria_input = gr.Textbox(
                            label="Screening Criteria (JSON)",
                            placeholder="""{"MW": {"max": 500}, "LogP": {"min": 0, "max": 5}, "TPSA": {"max": 140}}""",
                            lines=3,
                            value="""{"MW": {"max": 500}, "LogP": {"min": 0, "max": 5}, "TPSA": {"max": 140}}"""
                        )
                        screen_target_input = gr.Textbox(
                            label="Target Focus (optional)",
                            placeholder="Enter target name or disease area"
                        )
                        screen_button = gr.Button("Screen Compounds")
                with gr.Row():
                    screening_output = gr.Textbox(
                        label="Screening Results",
                        lines=8
                    )
                    with gr.Column():
                        result_count = gr.Number(
                            label="Number of Hits",
                            interactive=False
                        )
                        
            # About Tab
            with gr.Tab("About"):
                gr.Markdown("""
                # AI-Powered Drug Discovery Platform
                
                This platform was developed as a Senior Design project (COMP 4710) during Spring 2025 at Auburn University's Department of Computer Science and Software Engineering.
                
                ## Team Members
                - Brady Hauglie
                - Cale Johnson
                - Spencer Purdy
                
                ## Faculty Oversight
                Dr. Gerry Dozier, Professor, Department of Computer Science and Software Engineering
                
                ## Project Sponsor
                Dr. Rajesh Amin, Department of Drug Discovery and Development, Auburn University
                
                ## Overview
                This platform integrates AI capabilities with RDKit and other molecular modeling tools to assist researchers in drug discovery. Key features include protein target analysis, compound property calculation, ADME prediction, structure optimization, and compound screening against drug-likeness criteria.
                
                ## Technologies
                - Python with RDKit for computational chemistry
                - OpenAI API for AI-assisted analysis and optimization
                - Gradio for the web interface
                - BioPython for protein structure analysis
                
                ## License
                This project is licensed under the Apache License 2.0. The Apache License was chosen to provide patent protection in addition to copyright, which is particularly relevant for drug discovery applications.
                
                Copyright © 2025 Brady Hauglie, Cale Johnson, Spencer Purdy
                
                Licensed under the Apache License, Version 2.0 (the "License");
                you may not use this file except in compliance with the License.
                You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
                """)
                
            # Helper Functions
            def process_molecule(smiles):
                """Process molecule and return 2D structure and properties"""
                try:
                    # Basic sanitization
                    smiles = SecurityUtil.sanitize_input(smiles)
                    
                    mol = Chem.MolFromSmiles(smiles)
                    if mol is None:
                        return None, {"error": "Invalid SMILES string"}, {"error": "Invalid SMILES string"}

                    # Generate 2D image
                    img = Draw.MolToImage(mol)

                    # Calculate properties
                    properties = self.agent.property_calculator.calculate_properties(mol)
                    
                    # Calculate ADME properties
                    adme = self.agent.property_calculator.predict_adme(mol)

                    return img, properties, adme
                except Exception as e:
                    return None, {"error": str(e)}, {"error": str(e)}

            def analyze_protein(api_key, pdb_id, description):
                """Handle protein analysis"""
                try:
                    if not api_key:
                        return "Error: API key is required"
                    
                    result = self.agent.analyze_protein_target(api_key, pdb_id, description)
                    return result.get('analysis', str(result))
                    
                except Exception as e:
                    return f"Error: {str(e)}"

            def analyze_target(api_key, target_name):
                """Handle target analysis"""
                try:
                    if not api_key:
                        return "Error: API key is required"
                    
                    result = self.agent.analyze_target(api_key, target_name)
                    return result.get('analysis', str(result))
                    
                except Exception as e:
                    return f"Error: {str(e)}"
                    
            def evaluate_compound_for_target(api_key, target_name, smiles):
                """Handle compound evaluation for target"""
                try:
                    if not api_key:
                        return "Error: API key is required"
                    
                    if not smiles:
                        return "Error: SMILES string is required"
                        
                    result = self.agent.evaluate_for_target(api_key, target_name, smiles)
                    return result.get('evaluation', str(result))
                    
                except Exception as e:
                    return f"Error: {str(e)}"

            def screen_compounds_text(api_key, smiles_text, criteria_json, target_focus):
                """Handle compound screening from text input"""
                try:
                    if not api_key:
                        return "Error: API key is required", 0
                    
                    if not smiles_text:
                        return "Error: Please enter SMILES strings", 0
                        
                    criteria = json.loads(criteria_json)
                    
                    # Process the SMILES input
                    compounds = self.agent.process_smiles_input(smiles_text)
                    
                    # Screen the compounds
                    result = self.agent.screen_compounds(api_key, compounds, criteria, target_focus)
                    
                    # Update hit count
                    hit_count = len(result.get('hits', []))
                    
                    return json.dumps(result, indent=2), hit_count
                    
                except Exception as e:
                    return f"Error: {str(e)}", 0

            def optimize_compound(api_key, smiles, goals, target_name):
                """Handle compound optimization"""
                try:
                    if not api_key:
                        return "Error: API key is required"
                    
                    # If target name is empty, set to None
                    if not target_name:
                        target_name = None
                        
                    # Split goals into list
                    goals_list = [g.strip() for g in goals.split(',')]
                    
                    result = self.agent.optimize_compound(api_key, smiles, goals_list, target_name)
                    
                    return result.get('suggestions', str(result))
                    
                except Exception as e:
                    return f"Error: {str(e)}"

            # Connect Event Handlers
            smiles_input.change(
                fn=process_molecule,
                inputs=smiles_input,
                outputs=[mol_2d, mol_properties, mol_adme]
            )

            analyze_button.click(
                fn=analyze_protein,
                inputs=[api_key_input, pdb_id_input, target_description_input],
                outputs=protein_analysis_output
            )
            
            analyze_target_button.click(
                fn=analyze_target,
                inputs=[api_key_input, target_input],
                outputs=target_analysis
            )
            
            evaluate_target_button.click(
                fn=evaluate_compound_for_target,
                inputs=[api_key_input, target_name_input, compound_for_target_input],
                outputs=target_evaluation_output
            )
            
            screen_button.click(
                fn=screen_compounds_text,
                inputs=[api_key_input, compounds_text_input, screening_criteria_input, screen_target_input],
                outputs=[screening_output, result_count]
            )
            
            optimize_button.click(
                fn=optimize_compound,
                inputs=[api_key_input, smiles_input, optimization_goals_input, optimization_target_input],
                outputs=optimization_output
            )

        return interface

#-------------------------------------------------------------------------------
# Main Execution and Example Usage
#-------------------------------------------------------------------------------

def main():
    """Initialize and launch the drug design platform"""
    try:
        # Initialize core components
        memory_manager = MemoryManager()
        agent = DrugDesignAgent(memory_manager)
        interface = DrugDesignInterface(agent)

        # Launch interface
        demo = interface.create_interface()
        demo.launch()

    except Exception as e:
        print(f"Error starting application: {str(e)}")
        raise

#-------------------------------------------------------------------------------
# Example Usage Guide
#-------------------------------------------------------------------------------

# Example Usage Guide
USAGE_GUIDE = """
AI-Assisted Drug Design Platform - Quick Start Guide
---------------------------------------------------------------------------------

1. Setup:
   - Enter your OpenAI API key in the Setup tab
   - The key is required for AI-assisted analysis and optimization

2. Target Analysis:
   - Enter a target name (EGFR, ACE2, etc.)
   - Get detailed analysis of the target's role in disease
   - Evaluate compounds for specific targets

3. General Protein Analysis:
   - Enter any PDB ID for analysis
   - Add a description of your target and goals
   - Get AI-assisted binding site analysis

4. Compound Design:
   - Enter a SMILES string to analyze
   - Properties and ADME profiles will be calculated automatically
   - Add optimization goals and target focus
   - Get structure modification suggestions

5. Compound Screening:
   - Enter multiple SMILES strings in the text area (one per line)
   - Customize screening criteria as JSON
   - Focus screening on specific targets or disease areas
   - View screening results instantly

Example SMILES to try:
- Aspirin: CC(=O)OC1=CC=CC=C1C(=O)O
- Ibuprofen: CC(C)CC1=CC=C(C=C1)C(C)C(=O)O
- Erlotinib (EGFR inhibitor): COCCOC1=C(C=C2C(=C1)C(=NC=N2)NC3=CC=CC(=C3)C#C)OCCOC
"""

if __name__ == "__main__":
    # Display usage guide
    print(USAGE_GUIDE)

    # Launch the platform
    main()