---
title: AI (ChatGPT) for Drug Discovery - Auburn University Senior Design Project
colorFrom: gray
colorTo: gray
sdk: gradio
sdk_version: 5.23.1
app_file: app.py
pinned: false
license: mit
short_description: AI-powered drug discovery platform for molecular design
---